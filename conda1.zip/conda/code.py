import os
import shutil

# 要复制的源目录
src_dir = "/path/to/source/directory"

# 目标目录
dst_dir = "/path/to/destination/directory"

# 要忽略的子目录列表
ignored_dirs = ["dir1", "dir2"]


# 过滤函数
def ignore_dirs(directory, contents):
    ignored = []
    for content in contents:
        rel_path = os.path.relpath(os.path.join(directory, content), src_dir)
        if any(ignored_dir in rel_path for ignored_dir in ignored_dirs):
            ignored.append(content)
    return ignored


# 复制目录,忽略特定子目录
shutil.copytree(src_dir, dst_dir, ignore=ignore_dirs)
